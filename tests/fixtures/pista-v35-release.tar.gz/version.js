globalThis.PISTA_RELEASE = {
  "version": "3.5.0",
  "id": "ce9fc764a93267a974b6f1f0a0d959ba4636729327c081f6c5162c5bc7609bbb",
  "assets": {
    "index.html": "e66851cd1a8bf76b82bce590870ccf43d6d7054e611d74e727c3de0e6d44d3ef",
    "styles.css": "468970ff5270c9ec9f2e4e7da912cef0480ff8d65b658749bec5ad343d6f735b",
    "refinements.css": "f7dc45562ba9f7a4b1482e158b13bf5437da5acf01af5704b40e9089a89246ed",
    "tracker.css": "b303784cdb72a6778030bba840d69bf88bea616cb3cebe6a301533a54a704e7a",
    "app.js": "4575de9632c8a4a233ee94e471adbf377779b421c073f947fa957a0acde40501",
    "core.js": "858b6b4359e37e071856b6ca7b0531b2c8bd2931c5b62d9edfcbcfde2ae03edb",
    "tracker-view.js": "7e15ee5e474ea7672100b532f72b822f624115607687722c86632c96c0787fde",
    "training-plan.js": "7b4a41ab45b52aca30ecd713c7bbbd53573107109dbb7b6f192da4145a81fc26",
    "pdf.js": "182646c807ecb3720d9a7f6b5157a7f916d23588dd299fa010e364043254c50c",
    "pwa.js": "51e009465086ee894bc848a29fd5909bd427ad52741fd8be254320bad07e9e27",
    "github-backup.js": "e1067fe543757a3cd63af39956a756bc25b40c19b6205e001bf345bffd58ae13",
    "logo.svg": "fd97fa1aaaadcf58c6a6d0a9fb545fd787e510b4baa67296835b1d4941db5d12",
    "manifest.webmanifest": "71c37fedb7bb9b1d72dd893986a1fe91f374655288dea5633babcf4690b50c64",
    "icons/icon-192.png": "5bb662a864bc44bf3ca67e922fddb5fb996e85309171e97ddbffac8311fe329b",
    "icons/icon-512.png": "d267c3c33e645b3bfc9650504f3fd32f84f601b38a02b8de523c9e4da6e456c5",
    "icons/maskable-512.png": "4b84797836653742bb4c67afeb981cb53cd539ef6fb5dc85ef3853290a2778ab",
    "icons/apple-touch-icon.png": "02f8bbf86674a95e53f745bc11e22d6e036625f9e2642e94da1d152ac4c47b05"
  }
};
